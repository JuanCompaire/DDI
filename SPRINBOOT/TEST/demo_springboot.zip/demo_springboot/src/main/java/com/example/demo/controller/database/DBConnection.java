package com.example.demo.controller.database;

public interface DBConnection {

	void helloFromWhateverDatabase();

}
