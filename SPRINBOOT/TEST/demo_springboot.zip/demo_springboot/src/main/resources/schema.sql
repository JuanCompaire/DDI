create table students(
	id int NOT NULL AUTO_INCREMENT,
	nombre varchar(100) not null,
	apellido varchar(100) not null,
	PRIMARY KEY(id)
);